# Nupixel Roadmap

## Stage 0 — Repository and build audit
- Inspect source tree, Git state, JDK, Android SDK and Gradle.
- Confirm dependency/license compatibility.
- Record decisions in `ARCHITECTURE.md`.

## Stage 1 — Working Android foundation
- [x] Kotlin/Compose application structure
- [x] Dark starter workspace
- [x] Touch drawing and brush controls
- [x] System image import
- [x] PNG export implementation
- [ ] Build and smoke-test on Android SDK
- [ ] Persist settings and recover drafts

## Stage 2 — Raster editing basics
- [ ] Separate document model from UI
- [ ] Brush, eraser, eyedropper, fill, shapes and crop
- [ ] Undo/redo with bounded memory usage
- [ ] Transform tools and gesture-tested canvas navigation

## Stage 3 — Layer engine
- [ ] Layer model, ordering, visibility, opacity and lock
- [ ] Compositing and thumbnails
- [ ] Groups and masks

## Stage 4 — Project engine
- [ ] Versioned `.nupixel` project container
- [ ] Atomic saves, autosave and recovery
- [ ] Schema migrations and corruption handling

## Stage 5 — Adjustments and effects
- [ ] Brightness, contrast, hue, saturation and white balance
- [ ] Blur, sharpen and levels
- [ ] Non-destructive adjustment stack

## Stage 6 — Selection and retouch
- [ ] Rectangular/elliptical and color-based selection
- [ ] Masks, clone and healing tools

## Stage 7 — Digital painting
- [ ] Brush presets, textured tips and stroke stabilization
- [ ] Stylus pressure when supported by device

## Stage 8 — Graphic design and vector
- [ ] Editable text, gradients, shapes and SVG import/export
- [ ] Bezier paths and node editing

## Stage 9 — Animation
- [ ] Frame timeline and onion skin
- [ ] GIF export
- [ ] MP4 export and encoding tests

## Stage 10 — 3D
- [ ] Select licensed runtime and supported model formats
- [ ] Import, camera, transforms, materials and lighting

## Stage 11 — Batch processing and presets
- [ ] Batch queue, resizing, conversion and renaming
- [ ] User presets and import/export

## Stage 12 — Color management and print
- [ ] ICC-aware import/export
- [ ] sRGB and supported conversions
- [ ] DPI/PPI and print dimensions

## Stage 13 — Release hardening
- [ ] Unit, integration and UI tests
- [ ] Low-memory and interrupted-save tests
- [ ] Accessibility and localization audit
- [ ] Release signing instructions, license inventory and user guide
- [ ] Reproducible APK build and release checklist

A stage is complete only when its acceptance criteria and relevant tests have actually been run.
