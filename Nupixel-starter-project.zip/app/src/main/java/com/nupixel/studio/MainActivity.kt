package com.nupixel.studio

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Brush
import androidx.compose.material.icons.filled.FileOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NupixelApp() }
    }
}

private data class StrokeData(val points: List<Offset>, val color: Color, val width: Float)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NupixelApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var english by remember { mutableStateOf(false) }
    var strokes by remember { mutableStateOf(listOf<StrokeData>()) }
    var activePoints by remember { mutableStateOf(listOf<Offset>()) }
    var activeColor by remember { mutableStateOf(Color(0xFF8B7CFF)) }
    var brushWidth by remember { mutableFloatStateOf(8f) }
    var importedBitmap by remember { mutableStateOf<Bitmap?>(null) }
    var status by remember { mutableStateOf(if (english) "Ready" else "Готово") }

    val importLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            scope.launch {
                val bitmap = withContext(Dispatchers.IO) {
                    context.contentResolver.openInputStream(uri)?.use {
                        BitmapFactory.decodeStream(it)
                    }
                }
                importedBitmap = bitmap
                status = if (bitmap != null) {
                    if (english) "Image imported" else "Изображение импортировано"
                } else {
                    if (english) "Could not open image" else "Не удалось открыть изображение"
                }
            }
        }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF9D90FF),
            background = Color(0xFF101116),
            surface = Color(0xFF191A22)
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("NUPIXEL", style = MaterialTheme.typography.titleLarge)
                            Text(
                                if (english) "Creative studio • Preview build" else "Творческая студия • Начальная версия",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    actions = {
                        IconButton(onClick = { english = !english }) {
                            Text(if (english) "RU" else "EN")
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(
                        selected = true,
                        onClick = { status = if (english) "Canvas workspace" else "Рабочее пространство холста" },
                        icon = { Icon(Icons.Default.Brush, null) },
                        label = { Text(if (english) "Canvas" else "Холст") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = { importLauncher.launch("image/*") },
                        icon = { Icon(Icons.Default.FileOpen, null) },
                        label = { Text(if (english) "Import" else "Импорт") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = {
                            if (strokes.isNotEmpty()) strokes = strokes.dropLast(1)
                            status = if (english) "Last stroke undone" else "Последний штрих отменён"
                        },
                        icon = { Icon(Icons.Default.Undo, null) },
                        label = { Text(if (english) "Undo" else "Отмена") }
                    )
                    NavigationBarItem(
                        selected = false,
                        onClick = {
                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    exportCanvas(context, strokes, importedBitmap)
                                }
                                status = if (result) {
                                    if (english) "PNG exported to Pictures/Nupixel" else "PNG сохранён в Pictures/Nupixel"
                                } else {
                                    if (english) "Export failed" else "Ошибка экспорта"
                                }
                            }
                        },
                        icon = { Icon(Icons.Default.Save, null) },
                        label = { Text(if (english) "Export" else "Экспорт") }
                    )
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF101116))
                    .padding(padding)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(if (english) "Brush" else "Кисть", style = MaterialTheme.typography.titleMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(Color(0xFFF5F5F7), Color(0xFF8B7CFF), Color(0xFFFF6B8A), Color(0xFF66D9A8), Color(0xFFFFC857))
                            .forEach { color ->
                                Surface(
                                    onClick = { activeColor = color },
                                    shape = RoundedCornerShape(50),
                                    color = color,
                                    modifier = Modifier.size(26.dp),
                                    border = if (activeColor == color) androidx.compose.foundation.BorderStroke(2.dp, Color.White) else null
                                ) {}
                            }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (english) "Size" else "Размер", modifier = Modifier.width(64.dp))
                    Slider(
                        value = brushWidth,
                        onValueChange = { brushWidth = it },
                        valueRange = 2f..32f,
                        modifier = Modifier.weight(1f)
                    )
                    Text("${brushWidth.toInt()} px")
                }

                Surface(
                    modifier = Modifier.fillMaxWidth().weight(1f),
                    color = Color(0xFFF4F3F8),
                    shape = RoundedCornerShape(18.dp)
                ) {
                    Canvas(
                        modifier = Modifier
                            .fillMaxSize()
                            .pointerInput(activeColor, brushWidth, strokes) {
                                detectDragGestures(
                                    onDragStart = { point -> activePoints = listOf(point) },
                                    onDrag = { change, _ ->
                                        activePoints = activePoints + change.position
                                    },
                                    onDragEnd = {
                                        if (activePoints.isNotEmpty()) {
                                            strokes = strokes + StrokeData(activePoints, activeColor, brushWidth)
                                            activePoints = emptyList()
                                        }
                                    }
                                )
                            }
                    ) {
                        importedBitmap?.let { bitmap ->
                            drawImage(
                                image = bitmap.asImageBitmap(),
                                dstSize = androidx.compose.ui.unit.IntSize(size.width.toInt(), size.height.toInt())
                            )
                        }
                        (strokes + listOfNotNull(
                            if (activePoints.isNotEmpty()) StrokeData(activePoints, activeColor, brushWidth) else null
                        )).forEach { stroke ->
                            if (stroke.points.size == 1) {
                                drawCircle(stroke.color, stroke.width / 2, stroke.points.first())
                            } else if (stroke.points.size > 1) {
                                val path = Path().apply {
                                    moveTo(stroke.points.first().x, stroke.points.first().y)
                                    stroke.points.drop(1).forEach { lineTo(it.x, it.y) }
                                }
                                drawPath(
                                    path = path,
                                    color = stroke.color,
                                    style = androidx.compose.ui.graphics.drawscope.Stroke(
                                        width = stroke.width,
                                        cap = StrokeCap.Round
                                    )
                                )
                            }
                        }
                    }
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Add, contentDescription = null, tint = Color(0xFF9D90FF))
                    Text(
                        if (english) "Touch and drag to draw. Import an image or export your canvas."
                        else "Касайся и веди пальцем, чтобы рисовать. Импортируй изображение или экспортируй холст.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Text(status, style = MaterialTheme.typography.labelSmall, color = Color(0xFFB8B5C8))
            }
        }
    }
}

private fun exportCanvas(
    context: android.content.Context,
    strokes: List<StrokeData>,
    imported: Bitmap?
): Boolean {
    return try {
        val width = imported?.width ?: 1080
        val height = imported?.height ?: 1440
        val bitmap = Bitmap.createBitmap(width.coerceAtLeast(1), height.coerceAtLeast(1), Bitmap.Config.ARGB_8888)
        val canvas = android.graphics.Canvas(bitmap)
        canvas.drawColor(android.graphics.Color.WHITE)
        imported?.let {
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG or android.graphics.Paint.FILTER_BITMAP_FLAG)
            canvas.drawBitmap(it, null, android.graphics.Rect(0, 0, width, height), paint)
        }
        val scaleX = width / 360f
        val scaleY = height / 640f
        strokes.forEach { stroke ->
            val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.argb(
                    (stroke.color.alpha * 255).toInt(),
                    (stroke.color.red * 255).toInt(),
                    (stroke.color.green * 255).toInt(),
                    (stroke.color.blue * 255).toInt()
                )
                style = android.graphics.Paint.Style.STROKE
                strokeCap = android.graphics.Paint.Cap.ROUND
                strokeJoin = android.graphics.Paint.Join.ROUND
                strokeWidth = stroke.width * ((scaleX + scaleY) / 2f)
            }
            val path = android.graphics.Path()
            stroke.points.forEachIndexed { index, point ->
                val x = point.x * scaleX
                val y = point.y * scaleY
                if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            canvas.drawPath(path, paint)
        }

        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "nupixel_${System.currentTimeMillis()}.png")
            put(MediaStore.Images.Media.MIME_TYPE, "image/png")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Nupixel")
        }
        val uri = context.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return false
        context.contentResolver.openOutputStream(uri)?.use { output ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, output)
        } ?: return false
        bitmap.recycle()
        true
    } catch (_: Exception) {
        false
    }
}
