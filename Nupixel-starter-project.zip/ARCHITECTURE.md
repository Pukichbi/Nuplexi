# Architecture decisions

## Initial stack
- Kotlin
- Android SDK
- Jetpack Compose + Material 3
- Android system document picker
- Android Bitmap/Canvas for the first PNG export path
- Coroutines for background image decoding/export

## Initial design
The current implementation is intentionally a small foundation. UI and drawing state are currently colocated and should be extracted into document, tool and rendering components as the next stage begins. Avoid creating many Gradle modules before clear boundaries and tests justify them.

## Next architectural priorities
1. Introduce a serializable document model independent of Compose.
2. Implement a renderer interface and explicit coordinate transforms.
3. Implement history commands with memory limits.
4. Add an atomic, versioned project format.
5. Keep image decoding and expensive rendering off the main thread.
6. Evaluate third-party dependencies and licenses before adding advanced format support.
