# Nupixel

Nupixel is an Android creative-studio project in active development.

## Current starter scope
- Kotlin + Jetpack Compose Android application.
- Dark creative-workspace UI.
- Touch drawing with a color palette and brush-size control.
- Image import through Android's system picker.
- PNG export to `Pictures/Nupixel`.
- Basic Russian/English UI toggle.

## Build requirements
- JDK 17
- Android SDK Platform 35
- Android Gradle Plugin 8.7.3 compatible Gradle 8.9 wrapper
- Android Studio recommended

Open this directory in Android Studio and allow Gradle sync. If a Gradle wrapper is not present, generate one from a machine with Gradle installed using `gradle wrapper --gradle-version 8.9`, then build with `./gradlew assembleDebug`.

Debug APK output, when successfully built:
`app/build/outputs/apk/debug/app-debug.apk`

## Important limitations
This is a starter implementation, not a finished professional editor. The current canvas is a basic drawing surface. Project-file persistence, real layer compositing, undo/redo history, non-destructive effects, vector editing, animation, 3D, ICC color management and PSD support are not yet implemented.

Build status must be verified in an actual Android SDK environment before claiming that an APK is ready.
